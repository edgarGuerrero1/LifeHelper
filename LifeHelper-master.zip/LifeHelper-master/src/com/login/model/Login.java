package com.login.model;

public class Login {
	private int id;
	private String perfil;
	private String email;
	private String pass;
	
	
}
